
# Off-Chain Verification Daemon (OCVD)

Service for processing KYC verification off-chain and anchoring proofs to Solana.

## Run

npm install
npm run dev

Server runs on port 3000.
