
export async function writeVerification(wallet:string,proof:any){
  console.log("Writing verification to chain",wallet,proof);
}
