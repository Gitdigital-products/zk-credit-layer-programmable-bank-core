
import express from "express";
import { addVerificationJob } from "./queue/queue";

export async function startServer() {

  const app = express();
  app.use(express.json());

  app.get("/health", (_,res)=>res.json({status:"ok"}));

  app.post("/verify", async (req,res)=>{
    const job = await addVerificationJob(req.body);
    res.json({jobId:job.id,status:"queued"});
  });

  app.listen(3000,()=>{
    console.log("OCVD running on 3000");
  });
}
