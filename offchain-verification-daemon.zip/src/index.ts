
import { startServer } from "./server";
import { initWorker } from "./queue/worker";

async function bootstrap() {
  await startServer();
  await initWorker();
}

bootstrap();
