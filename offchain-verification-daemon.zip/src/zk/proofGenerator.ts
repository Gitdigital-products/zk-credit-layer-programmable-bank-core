
export async function generateProof(input:any){

  return {
    proof:"mock-proof",
    publicSignals:[input.wallet,input.risk]
  };

}
