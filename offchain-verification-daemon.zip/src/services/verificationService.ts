
import { calculateRiskScore } from "./riskEngine";
import { generateProof } from "../zk/proofGenerator";

export async function verificationService(data:any){

  const risk = calculateRiskScore(data);

  const proof = await generateProof({
    wallet:data.wallet,
    risk
  });

  console.log("Verification complete",proof);
}
