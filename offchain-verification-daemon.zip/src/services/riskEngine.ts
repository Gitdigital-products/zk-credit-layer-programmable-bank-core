
export function calculateRiskScore(data:any){

  let score=0;

  if(data.country==="US") score+=5;
  if(data.age>21) score+=3;
  if(data.documentVerified) score+=10;

  return score;
}
