
import { Queue } from "bullmq";

export const verificationQueue = new Queue("verification",{
  connection:{host:"localhost",port:6379}
});

export function addVerificationJob(data:any){
  return verificationQueue.add("verify",data);
}
