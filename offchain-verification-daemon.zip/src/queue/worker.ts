
import { Worker } from "bullmq";
import { verificationService } from "../services/verificationService";

export async function initWorker(){

 new Worker(
  "verification",
  async job=>{
    await verificationService(job.data);
  },
  {connection:{host:"localhost",port:6379}}
 );

}
