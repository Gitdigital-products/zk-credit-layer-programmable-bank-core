# Code of Conduct

We are committed to providing a welcoming and respectful environment for all contributors.

## Our Standards
- Be respectful and inclusive
- Provide constructive feedback
- Avoid harassment or discriminatory behavior

Violations may result in removal from the project.
