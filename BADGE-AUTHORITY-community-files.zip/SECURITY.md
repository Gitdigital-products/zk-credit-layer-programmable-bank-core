# Security Policy

## Reporting a Vulnerability
If you discover a security vulnerability, please report it privately.

Do NOT create a public issue.

Contact: security@example.com

We will review and respond as quickly as possible.
