# Support

## Support Tiers

### Community Support
- GitHub Issues
- Documentation access

### Priority Support
- Direct email support
- 48-hour response window

### Enterprise Support
- Dedicated support channel
- SLA-backed response times
- Custom integrations

For support inquiries, contact: support@example.com
