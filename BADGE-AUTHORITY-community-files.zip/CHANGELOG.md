# Changelog

All notable changes to this project will be documented here.

## [Unreleased]

## [1.0.0] - 2026-02-22
- Initial structured community health files added
