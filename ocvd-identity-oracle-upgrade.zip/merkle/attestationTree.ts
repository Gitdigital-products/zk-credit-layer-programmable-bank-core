
import crypto from "crypto"

export function hash(data:string){
  return crypto.createHash("sha256").update(data).digest("hex")
}

export function buildTree(leaves:string[]){

  if(leaves.length === 1) return leaves[0]

  const next=[]

  for(let i=0;i<leaves.length;i+=2){

    const left=leaves[i]
    const right=leaves[i+1] || left

    next.push(hash(left+right))
  }

  return buildTree(next)

}
