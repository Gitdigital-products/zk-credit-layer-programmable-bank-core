
export async function resolveDID(did:string){

  if(!did.startsWith("did:")){
    throw new Error("Invalid DID")
  }

  return {
    id:did,
    publicKey:"examplePublicKey"
  }

}
