
export async function verifyZkLogin(token:string){

  if(!token){
    return { valid:false }
  }

  return {
    valid:true,
    wallet:"derivedWallet"
  }

}
