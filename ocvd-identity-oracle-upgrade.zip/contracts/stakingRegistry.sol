
pragma solidity ^0.8.0;

contract VerifierStaking {

    mapping(address => uint256) public stakes;

    function stake() public payable {
        stakes[msg.sender] += msg.value;
    }

    function slash(address verifier, uint256 amount) public {

        require(stakes[verifier] >= amount);

        stakes[verifier] -= amount;
    }

}
