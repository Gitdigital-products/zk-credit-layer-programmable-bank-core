
export async function verifyCredential(vc:any){

  if(!vc.proof){
    return { valid:false }
  }

  return {
    valid:true,
    issuer:vc.issuer
  }

}
