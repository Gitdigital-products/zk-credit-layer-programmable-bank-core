
export function checkGrantEligibility(user:any){

  if(user.riskScore < 70){
    return {
      eligible:false,
      reason:"Risk score too low"
    }
  }

  if(user.sanctioned){
    return {
      eligible:false,
      reason:"Sanctioned identity"
    }
  }

  return {
    eligible:true
  }

}
