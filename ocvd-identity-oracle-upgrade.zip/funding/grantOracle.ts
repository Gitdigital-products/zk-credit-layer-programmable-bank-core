
import { checkGrantEligibility } from "./grantEligibilityEngine"

export async function evaluateGrant(user:any){

  const result = checkGrantEligibility(user)

  return {
    user:user.wallet,
    decision:result
  }

}
