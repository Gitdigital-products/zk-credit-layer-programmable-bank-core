
export class VerifierNode {

  id:string

  constructor(id:string){
    this.id = id
  }

  async verifyCredential(vc:any){

    if(!vc.signature){
      return { valid:false }
    }

    return {
      valid:true,
      verifier:this.id
    }
  }

}
