
export function verifierConsensus(results:any[]){

  const approvals = results.filter(r=>r.valid)

  const ratio = approvals.length / results.length

  return {
    approved: ratio > 0.66,
    confidence: ratio
  }

}
