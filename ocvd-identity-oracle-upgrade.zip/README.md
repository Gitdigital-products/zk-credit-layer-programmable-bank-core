
OCVD Identity Oracle Upgrade

This upgrade layer adds:

• Decentralized verifier node network
• Verifier staking and slashing contracts
• DID (Decentralized Identifier) support
• Verifiable Credential (VC) framework
• zk-login wallet verification hooks
• Grant eligibility engine for Funding OS

Architecture:

Wallet
 ↓
zk-login / DID
 ↓
Verifier Nodes
 ↓
Credential Validation
 ↓
Consensus Verification
 ↓
Merkle Attestation
 ↓
Solana Registry
 ↓
Grant Eligibility Engine
